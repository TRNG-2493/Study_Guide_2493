const { defineConfig } = require('cypress');
// Lecture 5: visual testing plugin
const { addMatchImageSnapshotPlugin } = require('@simonsmith/cypress-image-snapshot/plugin');

module.exports = defineConfig({
  e2e: {
    // Lecture 1: lets us write cy.visit('/') instead of the full URL
    baseUrl: 'http://localhost:8080',

    // Lecture 5: turns on Cypress Studio (recording user actions)
    experimentalStudio: true,

    setupNodeEvents(on, config) {
      // Lecture 4: cy.task('log', 'message') prints to the terminal
      on('task', {
        log(message) {
          console.log(message);
          return null;
        },
      });

      // Lecture 5: registers cy.matchImageSnapshot()
      addMatchImageSnapshotPlugin(on);

      return config;
    },
  },

  // Lecture 4: video is off by default; set to true to record runs
  video: false,
});
