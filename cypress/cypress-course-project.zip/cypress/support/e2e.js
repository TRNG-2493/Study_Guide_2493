// Runs before every spec file. Load custom commands here.
import './commands';

// Lecture 5: adds cy.matchImageSnapshot()
import { addMatchImageSnapshotCommand } from '@simonsmith/cypress-image-snapshot/command';

addMatchImageSnapshotCommand({
  failureThreshold: 0.02,        // allow up to 2% of pixels to differ
  failureThresholdType: 'percent',
});
