// Lecture 3: custom commands

// Logs in through the UI.
Cypress.Commands.add('login', (username, password) => {
  cy.visit('/login.html');
  cy.get('[data-cy=username]').type(username);
  cy.get('[data-cy=password]').type(password, { log: false }); // hide the password in the Command Log
  cy.get('[data-cy=login-submit]').click();
});

// Logs in once and reuses the session (localStorage) in later tests.
Cypress.Commands.add('loginWithSession', (username, password) => {
  cy.session([username, password], () => {
    cy.login(username, password);
    cy.url().should('include', '/dashboard.html');
  });
});

// Adds a todo on the Todos page.
Cypress.Commands.add('addTodo', (text) => {
  cy.get('[data-cy=new-todo]').type(`${text}{enter}`);
});

// Shorthand for cy.get('[data-cy=...]').
Cypress.Commands.add('getByCy', (value) => cy.get(`[data-cy=${value}]`));
