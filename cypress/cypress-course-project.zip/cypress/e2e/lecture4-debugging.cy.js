// Lecture 4: Debugging and Evidence
// Open mode (time-travel, pause, debug): npx cypress open
// Run mode (screenshots, video):        npx cypress run --spec cypress/e2e/lecture4-debugging.cy.js

describe('Lecture 4: time-travel debugging', () => {
  it('adds and completes a todo (hover each step in the Command Log)', () => {
    cy.visit('/todo.html');
    cy.get('[data-cy=new-todo]').type('Debug me{enter}');
    cy.get('[data-cy=todo-item]').should('have.length', 3);
    cy.contains('[data-cy=todo-item]', 'Debug me').find('[data-cy=todo-toggle]').check();
    cy.get('[data-cy=todo-count]').should('have.text', '1 item left');
    // In open mode: hover a command to see the page at that moment,
    // click it to pin the snapshot and print details to DevTools console.
  });
});

describe('Lecture 4: debugging actions', () => {
  it('pauses the test with cy.pause()', () => {
    cy.visit('/todo.html');
    // cy.pause(); // Uncomment in open mode. Use "Resume" or "Next" in the Command Log.
    cy.get('[data-cy=new-todo]').type('After the pause{enter}');
    cy.contains('After the pause').should('be.visible');
  });

  it('inspects a subject with .debug()', () => {
    cy.visit('/todo.html');
    // With DevTools open, .debug() stops here and exposes the element as `subject`.
    cy.get('[data-cy=todo-item]').first().debug().should('have.class', 'completed');
  });

  it('uses the debugger keyword inside .then()', () => {
    cy.visit('/');
    cy.get('[data-cy=count]').then(($count) => {
      // debugger; // Uncomment with DevTools open to stop here and inspect $count
      expect($count.text()).to.equal('0');
    });
  });
});

describe('Lecture 4: logging', () => {
  it('logs to the Command Log, browser console and terminal', () => {
    cy.visit('/products.html');
    cy.get('[data-cy=product]').its('length').then((count) => {
      cy.log(`Found ${count} products`);                          // Command Log
      console.log('Products on page:', count);                   // DevTools console
      cy.task('log', `Terminal: found ${count} products`);       // terminal (via cypress.config.js)
    });
  });
});

describe('Lecture 4: screenshots', () => {
  it('takes screenshots on demand', () => {
    cy.visit('/todo.html');
    cy.screenshot('todo-full-page');                               // whole page
    cy.get('[data-cy=todo-list]').screenshot('todo-list-only');    // one element
    cy.screenshot('todo-viewport', { capture: 'viewport' });       // visible area only
  });

  // Remove `.skip` to see a failing test.
  // In `cypress run`, a screenshot is saved automatically in cypress/screenshots.
  it.skip('fails on purpose to show the automatic failure screenshot', () => {
    cy.visit('/todo.html');
    cy.get('[data-cy=todo-item]').should('have.length', 5); // there are only 2
  });
});
