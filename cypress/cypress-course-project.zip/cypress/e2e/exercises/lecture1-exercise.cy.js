// Lecture 1 exercise: fill in each TODO.

describe('Lecture 1 exercise', () => {
  beforeEach(() => {
    // TODO 1: visit the home page
  });

  it('opens the Todos page from the navigation bar', () => {
    // TODO 2: click the "Todos" link (data-cy="nav-todo")
    // TODO 3: check the URL includes "/todo.html"
    // TODO 4: check the page title (data-cy="page-title") has the text "Todos"
  });

  it('decrements the counter twice', () => {
    // TODO 5: save the decrement button (data-cy="decrement") as an alias called "minus"
    // TODO 6: click the alias twice
    // TODO 7: check the counter (data-cy="count") shows "-2"
  });
});
