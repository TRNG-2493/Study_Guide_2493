// Lecture 5: Recording user actions (Cypress Studio) and editing generated code
// Studio needs `experimentalStudio: true` in cypress.config.js and runs in open mode only.

describe('Lecture 5: recorded with Cypress Studio', () => {
  // BEFORE: what a Studio recording typically looks like.
  // It works, but it is hard to read and has no assertions.
  it('adds todos (raw recording)', () => {
    cy.visit('/todo.html');
    /* ==== Generated with Cypress Studio ==== */
    cy.get('[data-cy="new-todo"]').clear();
    cy.get('[data-cy="new-todo"]').type('Buy milk');
    cy.get('[data-cy="add-todo"]').click();
    cy.get('[data-cy="new-todo"]').clear();
    cy.get('[data-cy="new-todo"]').type('Walk the dog');
    cy.get('[data-cy="add-todo"]').click();
    cy.get(':nth-child(3) > [data-cy="todo-toggle"]').check();
    cy.get('[data-cy="filter"]').select('completed');
    /* ==== End Cypress Studio ==== */
  });

  // AFTER: the same flow, edited by hand.
  // 1. Removed the unneeded .clear() calls
  // 2. Replaced the brittle :nth-child selector with cy.contains
  // 3. Reused the cy.addTodo() custom command
  // 4. Added assertions so the test actually checks something
  it('adds todos and filters completed ones (edited)', () => {
    cy.visit('/todo.html');
    cy.addTodo('Buy milk');
    cy.addTodo('Walk the dog');
    cy.get('[data-cy=todo-item]').should('have.length', 4);

    cy.contains('[data-cy=todo-item]', 'Buy milk').find('[data-cy=todo-toggle]').check();
    cy.get('[data-cy=filter]').select('Completed');

    cy.get('[data-cy=todo-text]')
      .should('have.length', 2)
      .and('contain', 'Install Cypress')
      .and('contain', 'Buy milk');
  });
});
