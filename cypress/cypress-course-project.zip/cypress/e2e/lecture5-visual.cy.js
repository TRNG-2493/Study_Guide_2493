// Lecture 5: Visual testing with @simonsmith/cypress-image-snapshot
// First run creates baselines in cypress/snapshots.
// Later runs compare against them.
// Update baselines: npx cypress run --spec cypress/e2e/lecture5-visual.cy.js --expose updateSnapshots=true

describe('Lecture 5: visual testing', () => {
  beforeEach(() => {
    cy.viewport(1280, 720); // fixed size so screenshots are comparable
  });

  it('matches the whole home page', () => {
    cy.visit('/');
    cy.get('[data-cy=page-title]').should('be.visible'); // wait for the page first
    cy.matchImageSnapshot('home-page');
  });

  it('matches a single element', () => {
    cy.visit('/todo.html');
    cy.get('[data-cy=todo-list]').matchImageSnapshot('todo-list');
  });

  it('blacks out content that changes between runs', () => {
    cy.visit('/products.html');
    cy.get('[data-cy=product]').should('have.length', 4);
    cy.matchImageSnapshot('products-page', {
      blackout: ['[data-cy=product-price]'], // prices could change, so hide them
    });
  });
});
