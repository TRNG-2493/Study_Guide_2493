// Lecture 2: Locate, Interact, Assert
// Run: npx cypress run --spec cypress/e2e/lecture2-locate-interact-assert.cy.js

describe('Lecture 2: element location', () => {
  beforeEach(() => {
    cy.visit('/todo.html');
  });

  it('finds elements with cy.get and a data-cy selector (best practice)', () => {
    cy.get('[data-cy=new-todo]').should('exist');
  });

  it('finds elements by CSS: id, class, attribute', () => {
    cy.get('#filter').should('exist');                         // id
    cy.get('.todos').should('exist');                          // class
    cy.get('input[placeholder="What needs to be done?"]')      // attribute
      .should('exist');
  });

  it('finds elements by text with cy.contains', () => {
    cy.contains('Write first test').should('exist');
    cy.contains('button', 'Clear completed').should('exist');  // tag + text
  });

  it('narrows the search with .find and .within', () => {
    cy.get('[data-cy=todo-list]').find('[data-cy=todo-item]').should('have.length', 2);

    cy.get('[data-cy=todo-item]').first().within(() => {
      // Only looks inside the first todo item
      cy.get('[data-cy=todo-text]').should('have.text', 'Install Cypress');
    });
  });

  it('picks one element from many with .first, .last and .eq', () => {
    cy.get('[data-cy=todo-text]').first().should('have.text', 'Install Cypress');
    cy.get('[data-cy=todo-text]').last().should('have.text', 'Write first test');
    cy.get('[data-cy=todo-text]').eq(1).should('have.text', 'Write first test');
  });
});

describe('Lecture 2: element interaction', () => {
  beforeEach(() => {
    cy.visit('/todo.html');
  });

  it('types and clicks to add a todo', () => {
    cy.get('[data-cy=new-todo]').type('Learn assertions');
    cy.get('[data-cy=add-todo]').click();
    cy.get('[data-cy=todo-item]').should('have.length', 3);
  });

  it('presses Enter with a special key sequence', () => {
    cy.get('[data-cy=new-todo]').type('Press enter to add{enter}');
    cy.contains('[data-cy=todo-text]', 'Press enter to add').should('be.visible');
  });

  it('clears an input', () => {
    cy.get('[data-cy=new-todo]').type('Typo').clear().should('have.value', '');
  });

  it('checks and unchecks a checkbox', () => {
    cy.get('[data-cy=todo-toggle]').eq(1).check();
    cy.get('[data-cy=todo-count]').should('have.text', '0 items left');
    cy.get('[data-cy=todo-toggle]').eq(1).uncheck();
    cy.get('[data-cy=todo-count]').should('have.text', '1 item left');
  });

  it('selects an option from a dropdown', () => {
    cy.get('[data-cy=filter]').select('Completed');            // by visible text
    cy.get('[data-cy=todo-item]').should('have.length', 1);
    cy.get('[data-cy=filter]').select('active');               // by value
    cy.get('[data-cy=todo-text]').should('have.text', 'Write first test');
  });

  it('fires a raw DOM event with .trigger', () => {
    cy.get('[data-cy=add-todo]').trigger('mouseover');         // e.g. to show a hover tooltip
  });
});

describe('Lecture 2: assertions', () => {
  it('uses common should() assertions', () => {
    cy.visit('/todo.html');
    cy.get('[data-cy=todo-item]').should('have.length', 2);
    cy.get('[data-cy=todo-item]').first().should('have.class', 'completed');
    cy.get('[data-cy=todo-toggle]').first().should('be.checked');
    cy.get('[data-cy=todo-toggle]').last().should('not.be.checked');
    cy.get('[data-cy=new-todo]').should('have.attr', 'placeholder', 'What needs to be done?');
    cy.get('[data-cy=todo-count]').should('contain', 'item');
  });

  it('chains several assertions with .and', () => {
    cy.visit('/');
    cy.get('[data-cy=page-title]')
      .should('be.visible')
      .and('have.text', 'Cypress Practice App')
      .and('have.css', 'font-weight', '700');
  });

  it('retries until the assertion passes (no manual waits)', () => {
    cy.visit('/');
    cy.get('[data-cy=show-message]').click();
    // The message appears after 1.5 s. Cypress keeps retrying for up to 4 s.
    cy.get('[data-cy=message]').should('be.visible').and('have.text', 'Hello from Cypress!');
  });

  it('raises the timeout for a slow element', () => {
    cy.visit('/');
    cy.get('[data-cy=show-message]').click();
    cy.get('[data-cy=message]', { timeout: 10000 }).should('be.visible');
  });

  it('uses expect() inside .then() for complex checks', () => {
    cy.visit('/todo.html');
    cy.get('[data-cy=todo-text]').then(($items) => {
      const texts = [...$items].map((el) => el.innerText);
      expect(texts).to.deep.equal(['Install Cypress', 'Write first test']);
    });
  });
});
