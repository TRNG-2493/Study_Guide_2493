// Lecture 1: Foundations
// Run: npx cypress run --spec cypress/e2e/lecture1-foundations.cy.js

describe('Lecture 1: first tests', () => {
  // Runs before each test, like a Pytest fixture with function scope.
  beforeEach(() => {
    cy.visit('/'); // baseUrl + '/' -> http://localhost:8080/
  });

  it('loads the home page', () => {
    cy.title().should('eq', 'Cypress Practice App');
    cy.get('[data-cy=page-title]').should('have.text', 'Cypress Practice App');
  });

  it('navigates to the login page', () => {
    cy.get('[data-cy=nav-login]').click();
    cy.url().should('include', '/login.html');
    cy.get('[data-cy=page-title]').should('have.text', 'Login');
  });
});

describe('Lecture 1: the async model', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('queues commands: plain JS runs first, Cypress commands run later', () => {
    console.log('1. plain JS - runs immediately');
    cy.get('[data-cy=page-title]').then(() => {
      console.log('3. inside .then() - runs when Cypress reaches this command');
    });
    console.log('2. plain JS - also runs immediately, before any cy command');
    // Open DevTools (F12) > Console in the Cypress runner to see the order: 1, 2, 3.
  });

  it('uses .then() to work with a value from the page', () => {
    cy.get('[data-cy=count]').invoke('text').then((text) => {
      const before = Number(text);
      cy.get('[data-cy=increment]').click();
      cy.get('[data-cy=count]').should('have.text', String(before + 1));
    });
  });

  it('uses an alias to refer to an element again', () => {
    cy.get('[data-cy=increment]').as('plusButton');
    cy.get('@plusButton').click();
    cy.get('@plusButton').click();
    cy.get('[data-cy=count]').should('have.text', '2');
  });

  it('uses cy.wrap() to bring a plain value into the command chain', () => {
    const expected = { title: 'Cypress Practice App' };
    cy.wrap(expected).its('title').should('eq', 'Cypress Practice App');
  });
});
