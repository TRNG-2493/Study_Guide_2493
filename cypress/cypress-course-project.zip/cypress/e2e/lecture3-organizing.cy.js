// Lecture 3: Organizing Tests
// Run: npx cypress run --spec cypress/e2e/lecture3-organizing.cy.js

describe('Lecture 3: test selection', () => {
  // Change `it` to `it.only` to run just that test,
  // or `it.skip` to skip it. Same works for `describe`.
  it('runs normally', () => {
    cy.visit('/');
    cy.get('[data-cy=page-title]').should('be.visible');
  });

  it.skip('is skipped (shows as "pending" in the results)', () => {
    cy.visit('/does-not-exist.html');
  });
});

describe('Lecture 3: fixtures', () => {
  it('loads a fixture with cy.fixture().then()', () => {
    cy.fixture('users.json').then((users) => {
      const { username, password } = users.valid[0];
      cy.visit('/login.html');
      cy.get('[data-cy=username]').type(username);
      cy.get('[data-cy=password]').type(password);
      cy.get('[data-cy=login-submit]').click();
      cy.get('[data-cy=welcome]').should('contain', username);
    });
  });

  // Aliased fixtures are available as this.<alias>.
  // This needs `function () {}`, not an arrow function.
  describe('with an alias in beforeEach', () => {
    beforeEach(function () {
      cy.fixture('users.json').as('users');
      cy.visit('/login.html');
    });

    it('shows an error for the invalid user', function () {
      cy.get('[data-cy=username]').type(this.users.invalid.username);
      cy.get('[data-cy=password]').type(this.users.invalid.password);
      cy.get('[data-cy=login-submit]').click();
      cy.get('[data-cy=login-error]').should('have.text', 'Invalid username or password');
    });
  });

  // Data-driven: one test per user in the fixture file.
  // require() reads the file when the spec loads, so we can loop over it.
  const users = require('../fixtures/users.json');
  users.valid.forEach(({ username, password }) => {
    it(`logs in as ${username}`, () => {
      cy.login(username, password);
      cy.get('[data-cy=welcome]').should('have.text', `Welcome, ${username}!`);
    });
  });
});

describe('Lecture 3: custom commands', () => {
  it('uses cy.login() from support/commands.js', () => {
    cy.login('student', 'cypress123');
    cy.url().should('include', '/dashboard.html');
  });

  it('uses cy.addTodo() and cy.getByCy()', () => {
    cy.visit('/todo.html');
    cy.addTodo('Buy milk');
    cy.addTodo('Walk the dog');
    cy.getByCy('todo-item').should('have.length', 4);
  });

  it('uses cy.loginWithSession() to log in once and reuse it', () => {
    cy.loginWithSession('student', 'cypress123');
    cy.visit('/dashboard.html'); // already logged in
    cy.getByCy('welcome').should('contain', 'student');
  });
});

describe('Lecture 3: cy.intercept demo', () => {
  it('stubs the products API with a fixture', () => {
    cy.intercept('GET', '**/api/products.json', { fixture: 'products.json' }).as('getProducts');
    cy.visit('/products.html');
    cy.wait('@getProducts');
    cy.getByCy('product').should('have.length', 2);
    cy.getByCy('product-name').first().should('have.text', 'Test Product A');
  });

  it('simulates a server error', () => {
    cy.intercept('GET', '**/api/products.json', { statusCode: 500 }).as('getProducts');
    cy.visit('/products.html');
    cy.wait('@getProducts');
    cy.getByCy('error').should('be.visible');
  });

  it('simulates an empty response', () => {
    cy.intercept('GET', '**/api/products.json', { body: [] });
    cy.visit('/products.html');
    cy.getByCy('empty').should('be.visible');
  });
});

describe('Lecture 3: browser management', () => {
  it('tests on a mobile-sized viewport', () => {
    cy.viewport('iphone-x');      // preset
    cy.visit('/');
    cy.getByCy('nav').should('be.visible');
    cy.viewport(1280, 720);       // width, height in pixels
  });

  it('reports which browser is running', () => {
    cy.log(`Browser: ${Cypress.browser.name} ${Cypress.browser.majorVersion}`);
    cy.log(`Headless: ${Cypress.browser.isHeadless}`);
  });
});
