// Lecture 4 exercise: solution

describe('Lecture 4 exercise (solution)', () => {
  it('Bug 1: adds a todo', () => {
    cy.visit('/todo.html');
    // Fix: the text was typed but never submitted. Add {enter}.
    cy.get('[data-cy=new-todo]').type('Buy milk{enter}');
    cy.get('[data-cy=todo-item]').should('have.length', 3);
  });

  it('Bug 2: filters completed todos', () => {
    cy.visit('/todo.html');
    // Fix: there is no "Done" option. The option text is "Completed".
    cy.get('[data-cy=filter]').select('Completed');
    cy.get('[data-cy=todo-item]').should('have.length', 1);
  });

  it('Bug 3: shows the welcome message', () => {
    cy.login('student', 'cypress123');
    // Fix: the real text ends with "!". Time-travel to the failed step to see it.
    cy.get('[data-cy=welcome]').should('have.text', 'Welcome, student!');
  });

  it('Bug 4: counts the products', () => {
    cy.visit('/products.html');
    cy.get('[data-cy=product-name]').should('have.length', 4);
    // Fix: the price includes a "$" sign.
    cy.get('[data-cy=product-price]').first().should('have.text', '$24.99');
  });

  it('Extra: save evidence', () => {
    cy.visit('/products.html');
    cy.get('[data-cy=product]').its('length').then((count) => {
      cy.log(`Products: ${count}`);
      cy.task('log', `Products: ${count}`);
    });
    cy.get('[data-cy=product-list]').screenshot('products-list');
  });
});
