// Lecture 2 exercise: solution

describe('Lecture 2 exercise: login form (solution)', () => {
  beforeEach(() => {
    cy.visit('/login.html');
  });

  it('shows an error when both fields are empty', () => {
    cy.get('[data-cy=login-submit]').click();
    cy.get('[data-cy=login-error]')
      .should('be.visible')
      .and('have.text', 'Username and password are required');
  });

  it('shows an error for a wrong password', () => {
    cy.get('[data-cy=username]').type('student');
    cy.get('[data-cy=password]').type('nope');
    cy.get('[data-cy=login-submit]').click();
    cy.get('[data-cy=login-error]').should('have.text', 'Invalid username or password');
  });

  it('logs in with valid credentials', () => {
    cy.get('[data-cy=username]').type('student');
    cy.get('[data-cy=password]').type('cypress123');
    cy.get('[data-cy=login-submit]').click();
    cy.url().should('include', '/dashboard.html');
    cy.get('[data-cy=welcome]').should('contain', 'student');
  });

  it('ticks the "Remember me" checkbox', () => {
    cy.get('[data-cy=remember]').check().should('be.checked');
  });
});
