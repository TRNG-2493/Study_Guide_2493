// Lecture 3 exercise: solution

describe('Lecture 3 exercise (solution)', () => {
  it('logs in as the admin user from the fixture file', () => {
    cy.fixture('users.json').then((users) => {
      const { username, password } = users.valid[1];
      cy.login(username, password);
    });
    cy.getByCy('welcome').should('have.text', 'Welcome, admin!');
  });

  it('logs out after logging in', () => {
    cy.login('student', 'cypress123');
    cy.getByCy('logout').click();
    cy.url().should('include', '/login.html');
  });

  it('searches the stubbed product list', () => {
    cy.intercept('GET', '**/api/products.json', { fixture: 'products.json' }).as('getProducts');
    cy.visit('/products.html');
    cy.wait('@getProducts');
    cy.getByCy('search').type('B');
    cy.getByCy('product').should('have.length', 1);
    cy.getByCy('product-name').should('have.text', 'Test Product B');
  });

  it('shows "No products found" for a search with no matches', () => {
    cy.intercept('GET', '**/api/products.json', { fixture: 'products.json' }).as('getProducts');
    cy.visit('/products.html');
    cy.wait('@getProducts');
    cy.getByCy('search').type('zzz');
    cy.getByCy('empty').should('be.visible');
  });
});
