// Lecture 5 exercise: solution

describe('Lecture 5 exercise (solution)', () => {
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  // Edited version of the Studio recording
  it('logs in and out as admin', () => {
    cy.login('admin', 'admin123');
    cy.url().should('include', '/dashboard.html');
    cy.get('[data-cy=welcome]').should('have.text', 'Welcome, admin!');

    cy.get('[data-cy=logout]').click();
    cy.url().should('include', '/login.html');
  });

  it('matches the login page', () => {
    cy.visit('/login.html');
    cy.get('[data-cy=login-form]').should('be.visible');
    cy.matchImageSnapshot('login-page');
  });

  it('matches the login error state', () => {
    cy.visit('/login.html');
    cy.get('[data-cy=username]').type('student');
    cy.get('[data-cy=password]').type('wrong');
    cy.get('[data-cy=login-submit]').click();
    cy.get('[data-cy=login-error]').should('be.visible');
    cy.get('[data-cy=login-form]').matchImageSnapshot('login-error');
  });
});
