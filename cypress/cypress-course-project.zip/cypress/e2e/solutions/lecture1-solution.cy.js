// Lecture 1 exercise: solution

describe('Lecture 1 exercise (solution)', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('opens the Todos page from the navigation bar', () => {
    cy.get('[data-cy=nav-todo]').click();
    cy.url().should('include', '/todo.html');
    cy.get('[data-cy=page-title]').should('have.text', 'Todos');
  });

  it('decrements the counter twice', () => {
    cy.get('[data-cy=decrement]').as('minus');
    cy.get('@minus').click();
    cy.get('@minus').click();
    cy.get('[data-cy=count]').should('have.text', '-2');
  });
});
